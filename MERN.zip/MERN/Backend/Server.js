const express = require("express");
const app = express();
const mongoose = require('mongoose');
const taskRoutes = require("./routes/taskRoute")

require('dotenv').config();

// app.get("/", (req,res) => {
//     res.send("Hello word")
// });

//


//middleware
app.use((req,res,next) => {
    console.log("path" + req.path + " method" + req.method);
    next();
});

app.use(express.json());

//DB connection
mongoose.connect(process.env.MONGO_URI)
    .then(() => {
        app.listen(process.env.PORT, ()=> {
            console.log(" DB connected successfully and listening to " + process.env.PORT);
        });
    }).catch((error) => console.log(error));


//routes middleware
app.use("/api/tasks", taskRoutes)